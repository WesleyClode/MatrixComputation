There are 2 folds
In ex2:
Small function:
"backwardsub.m": backward sub
"gradientDescentMulti.m": compute gradient descent
"forwardsub.m":forward sub
"cholesky_decomposition.m":cholesky decomposition
“normalEqn.m”:normal Eqation
"computeCostMulti.m": compute loss
"ex2.m": main code


In ex3:
"classicalGS.m": classical Gram-Schimidt mehtod.
"modifiedGS.m": Gram-Schimidt mehtod.
"ex3_4.m": the outputs are the answer of question 3(4)
