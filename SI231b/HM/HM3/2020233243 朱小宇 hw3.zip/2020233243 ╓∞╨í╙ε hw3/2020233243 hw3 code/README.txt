In the 6 codes, there are 4 function codes and 2 solution codes.
function:
"Cholesky_decomposition.m": the function that solves the LS BY the method of normal equation with Cholesky decomposition and forward/backward substitution.
"gradient_decent.m": the fucntion that solve the LS with gradient decent method.
"classicalGS.m": the function that decompose the matrix by classical Gram-Schimidt mehtod.
"modifiedGS.m": the function that decompose the matrix by modified Gram-Schimidt mehtod.

output:
"question2.m": the outputs are the answer of question 2
"question3_4.m": the outputs are the answer of question 3(4)
